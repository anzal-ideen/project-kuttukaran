from datetime import datetime
from odoo import api, fields, models, _
# import datetime
import base64
import logging
import xlrd
from odoo.exceptions import ValidationError, MissingError, UserError

_logger = logging.getLogger(__name__)


class Tenders(models.Model):
    _name = "tenders"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Tenders"

    name = fields.Char(string="TRN", readonly=True, required=True, copy=False, default='New')
    product = fields.Many2one('product.template', string="Product", store=True, force_save=True)
    requested_by = fields.Many2one('res.partner', string="Requested By", store=True, force_save=True, tracking=True)
    requested_to = fields.Many2one('res.partner', string="Vendor", store=True, force_save=True)
    quantity = fields.Float(string="Quantity")
    unit_price = fields.Float(string="Unit Price")
    total_price = fields.Float(string="Total Price")
    requested_date = fields.Date(string="Requested Date")
    expected_date = fields.Date(string="Expected Date")
    company_ids = fields.Many2many('res.partner', string="Requested To")
    product_requested_id = fields.Float(string="Product Request ID")

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('tender.request') or 'New'

        result = super(Tenders, self).create(vals)
        return result

