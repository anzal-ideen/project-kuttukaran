from datetime import datetime
from odoo import api, fields, models, _
# import datetime


class ProductRequestBudget(models.Model):
    _name = "product.request.budget"
    _description = "Product Request"

    company_id = fields.Many2one('res.company', string="Company Id", tracking=True)
    location = fields.Many2one('res.company', string="Location", tracking=True)
    department_id = fields.Many2one('hr.department', string="Department", tracking=True)
    expense_type = fields.Selection([('cap', 'CapEx'), ('op', 'OpEx')], string='Expense Type', tracking=True)
    from_date = fields.Date("From Date", required=True)
    to_date = fields.Date(string="To Date", required=True)
    amount_allowed = fields.Float(string="Amount Allowed", tracking=True)
    amount_used = fields.Float(string="Amount Used", tracking=True)
    amount_available = fields.Float(string="Amount Available", tracking=True)

    @api.onchange('company_id')
    def onchange_in_company_id(self):
        # print(self.id)
        department_data = self.env['hr.department'].sudo().search([('company_id', '=', self.company_id.id)])
        department_list = []
        for department_line in department_data:
            department_list.append(department_line.id)
        print(department_list)
        res = {'domain': {'department_id': [('id', 'in', department_list)]}}
