from odoo import api, fields, models, _


class UserInherit(models.Model):
    _inherit = "res.users"

    res_user_line_id = fields.One2many('res.users.line',
                                       'res_user_id',
                                       string='User Inherit Line',
                                       tracking=True)


class UserInheritLine(models.Model):
    _name = "res.users.line"

    company_id = fields.Many2one('res.company', string="Company Id")
    location = fields.Many2one('res.company', string="Location")
    department_id = fields.Many2one('hr.department', string="Department")
    designation = fields.Many2one('hr.job', string="Designation")

    res_user_id = fields.Many2one('res.users', string='User Id',
                                  invisible=True)

    @api.onchange('company_id')
    def onchange_in_company_id(self):
        # self.location = self.company_id
        print("self.company_id.id ", self.company_id.name)
        department_data = self.env['hr.department'].sudo().search([('company_id', '=', self.company_id.id)])
        print(department_data)
        department_list = []
        for departments in department_data:
            department_list.append(departments.id)
        print("department_list ", department_list)
        res = {'domain': {'department_id': [('id', 'in', department_list)]}}
        return res

    @api.onchange('department_id')
    def onchange_in_department_id(self):
        # self.location = self.company_id
        print("Inside department")
        print(self.department_id)
        job_data = self.env['hr.job'].sudo().search(
            [('company_id', '=', self.company_id.id), ('department_id', '=', self.department_id.id)])
        # print(department_data)
        job_list = []
        for job in job_data:
            job_list.append(job.id)
        print(job_list)
        res = {'domain': {'designation': [('id', 'in', job_list)]}}
        return res
