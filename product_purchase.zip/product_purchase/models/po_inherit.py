from odoo import api, fields, models, _


class PurchaseOrderInherit(models.Model):
    _inherit = "purchase.order"
    _description = 'Purchase Order'

    tender_rfq_id = fields.Integer(string="Tender RFQ ID")

    bill_to = fields.Many2one('res.partner', "Bill To", required=True)

    ship_to = fields.Many2one('res.partner', "Ship To", required=True)
