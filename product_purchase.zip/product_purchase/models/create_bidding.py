from datetime import datetime
from odoo import api, fields, models, _
# import datetime
import base64
import logging
import xlrd
from odoo.exceptions import ValidationError, MissingError, UserError

_logger = logging.getLogger(__name__)


class Bidding(models.Model):
    _name = "bidding"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Bidding"

    name = fields.Char(string="Bidding No", readonly=True, required=True, copy=False, default='New')
    product_request_id = fields.Many2one('product.request', string="Purchase Request")
    product_request_line_id = fields.Many2one('product.request.line', string="Purchase Request")
    product = fields.Many2one('product.template', string="Product")
    quantity = fields.Float(string="Quantity")
    unit_price = fields.Float(string="Unit price")
    date = fields.Date(string="Bidding Date")
    time = fields.Float(string='Time')
    status = fields.Selection(
        selection=[('draft', 'DRAFT'), ('live', 'LIVE'), ('cancel', 'CANCEL'), ('complete', 'COMPLETE')],
        string='Bidding Status',
        default='draft',
        required=True
    )
    deadline = fields.Date(string='DeadLine')
    vendors = fields.Many2many("res.partner", string="Vendors")
    top_vendor = fields.Many2one("res.partner", string="Top Vendor", tracking=True)
    top_vendor_price = fields.Float(string="Updating Price")

    duration = fields.Float(string="Duration")
    task_timer = fields.Boolean(string='Timer', default=False)
    is_user_working = fields.Boolean(
        'Is Current User Working', compute='_compute_is_user_working',
        help="Technical field indicating whether the current user is working. ")

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('bidding') or 'New'

        result = super(Bidding, self).create(vals)

        return result

    bidding_line_ids = fields.One2many('bidding.line', 'bidding_id',
                                               string='Bidding Lines', tracking=True)

    @api.onchange('unit_price')
    def onchange_in_unit_price(self):
        self.top_vendor_price = self.unit_price

    @api.onchange('product_request_id')
    def onchange_in_product_request_id(self):
        product_data = self.env['product.request.line'].sudo().search([('product_request_id', '=', self.product_request_id.id)])
        product_list = []
        for product_line in product_data:
            product_list.append(product_line.product.id)
        print(product_list)
        res = {'domain': {'product': [('id', 'in', product_list)]}}
        return res

    def start_bidding(self):
        print(len(self.vendors))
        if len(self.vendors) <= 1:
            raise ValidationError(_("There aren't enough vendors for the bidding."))
        else:
            print("success")
            for vendor in self.vendors:
                print("vendor.id ",vendor.id)
                print("self.id ", self.id)
                bid_vendors = self.env['bidding.vendor'].sudo().create({
                    'bid_id': self.id,
                    'vendor': vendor.id,
                })

            bidding_vendors = self.env['bidding.vendor'].sudo().search(
                [('bid_id', '=', self.id)])

            bidding_vendors = self.env['vendor.bid'].sudo().search(
                [('bid_id', '=', self.id)])

            for vendor_bid in bidding_vendors:
                vendor_bid.write({
                    'status': 'live'
                })

            for item in bidding_vendors:
                print("Vendor : ", item.request_to)
                print("bidding_id : ", item.bid_id)
                print("price: ", item.unit_price)
                print("rank: ", item.rank)
            print("start_bidding")
            self.status = "live"

    def end_bidding(self):
        print("Inside end")
        bidding_vendors = self.env['vendor.bid'].sudo().search(
            [('bid_id', '=', self.id)])
        print("heree")
        for vendor_bid in bidding_vendors:
            vendor_bid.write({
                'status': 'complete'
            })
        # top_vendor = self.env['vendor.bid'].search(
        #     [('bid_id', '=', self.id), ('rank', '=', 1)])
        print(self.top_vendor.id)
        tender_record = self.env['product.tender.line'].sudo().create({
            'vendor': self.top_vendor.id,
            # 'purchase_representative': user_id,
            # 'tender_deadline': top_vendor.deadline,
            'product_template_id': self.product.id,
            'company_id': self.product.company_id.id,
            'quantity': self.quantity,
            'unit_price': self.top_vendor_price,
            'total': self.quantity * self.top_vendor_price
        })
        self.status = 'complete'
        # --------------------------------------------------------------------- PO
        data = []
        child = []
        address = ''

        if self.top_vendor.street:
            address = address + str(self.top_vendor.street) + " "
        if self.top_vendor.street2:
            address = address + str(self.top_vendor.street2) + " "
        if self.top_vendor.city:
            address = address + str(self.top_vendor.city) + " "
        if self.top_vendor.state_id.name:
            address = address + str(self.top_vendor.state_id.name) + " "
        if self.top_vendor.zip:
            address = address + str(self.top_vendor.zip) + " "
        if self.top_vendor.country_id.name:
            address = address + str(self.top_vendor.country_id.name)

        if self.top_vendor:
            partner_id = {
                "name": self.top_vendor.name,
                "ref": "",
                "address": address,
                "phone": self.top_vendor.phone,
                "email": self.top_vendor.email,
                "gst_no": self.top_vendor.vat,
                "state": str(self.top_vendor.state_id.name)
            }
            # print("partner_id ", partner_id)
            child.append({
                "name": self.product.name,
                "product_qty": self.quantity,
                "discount": 0,
                "rate": self.unit_price,
                "cgst": 0,
                "sgst": 0,
                "igst": 0,
                "price_unit": self.top_vendor_price
            })
            # print("child ", child)
            master = {
                "orderID": None,
                "date_approve": datetime.now(),
                "partner_id": partner_id
            }

            data_dict = {
                "master": master,
                "child": child
            }
            data.append(data_dict)
            # print("data : ", data)

            for row in data:
                # print("---------------")
                invoice_date = row["master"]["date_approve"]
                # date = datetime.strptime(invoice_date, '%d/%m/%Y')
                vendor_gst = row["master"]["partner_id"]["gst_no"]
                if vendor_gst:
                    vendor = vendor_gst and self.env['res.partner'].sudo().search(
                        [('id', '=', self.top_vendor.id)],
                        limit=1) or False
                    if not vendor:
                        raise ValueError("Vendor is missing")
                else:
                    raise ValueError("GST number is missing")

                order_line = []
                for product_line in row["child"]:
                    product_item = product_line["name"]
                    if product_item:
                        product = product_item and self.env['product.product'].sudo().search(
                            [('name', '=', product_item)], limit=1) or False
                        uom_ids = self.env['uom.uom'].sudo().search([])
                        unit_id = self.env.ref('uom.product_uom_unit') and self.env.ref(
                            'uom.product_uom_unit').id or False
                        for record in uom_ids:
                            if record.name == "kg":
                                unit_id = record.id
                        if not product:
                            raise ValueError("Product is missing")
                            # print("product template")
                    if product:
                        order_line.append((0, 0, {
                            'display_type': False,
                            # 'sequence': 10,
                            'product_id': product.id,
                            'name': product.name or '',
                            # 'date_planned': row.TRANSACTION_DATE or False,
                            'account_analytic_id': False,
                            'product_qty': product_line["product_qty"] or 0,
                            'qty_received_manual': 0,
                            # 'discount': discount or 0,
                            # 'product_uom': product.uom_id.id or request.env.ref(
                            #     'uom.product_uom_unit') and request.env.ref('uom.product_uom_unit').id or False,
                            'price_unit': product_line["price_unit"] or 0,
                            # 'taxes_id': tax_variant and [(6, 0, [tax_variant.id])] or [],
                        }))
            if vendor:
                print("partner_id partner_id ", vendor.id)
                purchase_order_1 = self.env['purchase.order'].create({
                    'partner_id': vendor.id,
                    # 'partner_ref': row.SALES_ORDER_NUMBER or '',
                    # 'origin': row.INVOICE_NUM or '',
                    # 'date_order':row["master"]["date_order"] or False,
                    # 'date_planned':row["master"]["date_approve"] or False,
                    # 'partner_id': self.env.ref('base.main_partner').id,
                    # 'name': row.INVOICE_NUM or '',
                    'order_line': order_line,
                    'tender_rfq_id': self.id
                })
                # purchase_order_1.button_confirm()
                # self.tender_response_qtn_check = True
                self.env.cr.commit()


class BiddingLine(models.Model):
    _name = "bidding.line"
    _description = "Bidding Line"

    vendor = fields.Many2one("res.partner", string="Vendors")
    price = fields.Float(string="Price")

    bidding_id = fields.Many2one('bidding', string="Bidding", tracking=True)



