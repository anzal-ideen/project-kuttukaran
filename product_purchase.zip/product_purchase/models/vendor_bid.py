from odoo import api, fields, models
from odoo.exceptions import ValidationError, MissingError, UserError


class VendorBid(models.Model):
    _name = "vendor.bid"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Vendor Bid"

    name = fields.Char(string="Bid No", readonly=True, required=True, copy=False, default='New')
    Bid_name = fields.Char(string="BID Name")
    bid_id = fields.Many2one('bidding', string="Bid Id")
    bid_request_id = fields.Many2one('bid.request', string="Bid Request Id")
    request_from = fields.Many2one('res.partner', string="Vendor")
    request_to = fields.Many2one('res.partner', string="Requested to")
    product_id = fields.Many2one('product.template', string="Product")
    quantity = fields.Float(string="Quantity")
    unit_price = fields.Float(string="Unit price")
    rank = fields.Integer(string="Rank", default=0)
    updated_price = fields.Float(string="Your Price", tracking=True)
    time = fields.Float(string='Time')
    status = fields.Selection(
        selection=[('draft', 'DRAFT'), ('live', 'LIVE'), ('cancel', 'CANCEL'), ('complete', 'COMPLETE')],
        string='Bidding Status',
        default='draft',
        required=True
    )
    user_id = fields.Many2one('res.users', string="User Id")

    @api.depends('seconds', 'active')
    def _compute_time_left(self):
        for timer in self:
            if timer.active:
                timer.time_left = timer.seconds
            else:
                timer.time_left = 0

    def start_timer(self):
        self.active = True

    def pause_timer(self):
        self.active = False

    def reset_timer(self):
        self.active = False
        self.time_left = self.seconds

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('vendor.bid') or 'New'

        result = super(VendorBid, self).create(vals)

        return result

    def update_price(self):
        bidding = self.env['bidding'].sudo().search(
            [('id', '=', self.bid_id.id)], limit=1)
        if bidding:
            print("bidding.top_vendor_price : ", bidding.top_vendor_price)
            print("self.updated_price : ", self.updated_price)
            if bidding.top_vendor_price > self.updated_price:
                print("update_price")
                account_payment = self.env['bidding.line'].sudo().create({
                    'bidding_id': self.bid_id.id,
                    'vendor': self.request_to.id,
                    'price': self.updated_price
                })

                vendor_bid = self.env['vendor.bid'].sudo().search(
                    [('request_to', '=', self.request_to.id), ('bid_id', '=', self.bid_id.id)], limit=1)
                if vendor_bid:
                    vendor_bid.updated_price = self.updated_price

                all_bidding_vendor = self.env['vendor.bid'].sudo().search(
                    [('bid_id', '=', self.bid_id.id)], order='updated_price asc')
                num = 0
                for vendors in all_bidding_vendor:
                    num += 1
                    vendors.rank = num
                    if vendors.rank == 1:
                        bidding = self.env['bidding'].sudo().search(
                            [('id', '=', self.bid_id.id)], limit=1)
                        bidding.top_vendor = vendors.request_to
                        bidding.top_vendor_price = vendors.updated_price
                    print("vendors", vendors.rank)
            else:
                raise ValidationError("The current price of the product is lower than the price you requested.")
