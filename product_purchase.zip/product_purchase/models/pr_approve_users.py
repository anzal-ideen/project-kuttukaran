from datetime import datetime
from odoo import api, fields, models, _
# import datetime
import base64
import logging
import xlrd
from odoo.exceptions import ValidationError, MissingError, UserError

_logger = logging.getLogger(__name__)


class PrCompany(models.Model):
    _name = "pr.company"

    name = fields.Char(string="PR Company Number", readonly=True, required=True, copy=False, default='New')
    company_id = fields.Many2one('res.company', string="Company Id")
    location = fields.Many2one('res.company', string="Location")
    department_id = fields.Many2one('hr.department', string="Department")
    # , domain = "[('company_id','=',company_id)]"

    pr_approve_users_id = fields.One2many('pr.approve.users',
                                          'pr_company_id',
                                          string='Pr Approve Users',
                                          tracking=True)

    # product_request_budget_ids = fields.One2many('product.request.budget',
    #                                              'product_budget_id',
    #                                              string='Product Budget Line',
    #                                              tracking=True)

    from_amount = fields.Integer(string="From Amount")
    to_amount = fields.Integer(string="To Amount")
    expense_type = fields.Selection([('cap', 'CapEx'), ('op', 'OpEx')], string='Expense Type')

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            # print(self.company_id.name)
            vals['name'] = self.env['ir.sequence'].next_by_code('pr.company') or 'New'
        result = super(PrCompany, self).create(vals)
        return result

    @api.onchange('company_id')
    def onchange_in_company_id(self):
        # print(self.id)
        department_data = self.env['hr.department'].sudo().search([('company_id', '=', self.company_id.id)])
        department_list = []
        for department_line in department_data:
            department_list.append(department_line.id)
        print(department_list)
        res = {'domain': {'department_id': [('id', 'in', department_list)]}}


class PrApproveUsers(models.Model):
    _name = "pr.approve.users"

    user_id = fields.Many2one('res.users', string="User")
    company_id = fields.Many2one('res.company', string="Company Id")
    location = fields.Many2one('res.company', string="Location")
    department_id = fields.Many2one('hr.department', string="Department")
    designation = fields.Many2one('hr.job', string="Designation")
    approve_order = fields.Integer(string="Order")

    pr_company_id = fields.Many2one('pr.company', string='Pr Company Id',
                                    invisible=True)

    @api.onchange('company_id')
    def onchange_in_company_id(self):
        self.department_id = ""
        print("Inside company")
        department_data = self.env['hr.department'].sudo().search(
            [('company_id', '=', self.company_id.id)])
        dep_list = []
        for dep in department_data:
            dep_list.append(dep.id)
        print(dep_list)
        res = {'domain': {'department_id': [('id', 'in', dep_list)]}}
        return res

    @api.onchange('department_id')
    def onchange_in_department_id(self):
        print("Inside department")
        self.designation = ""
        job_data = self.env['hr.job'].sudo().search(
            [('company_id', '=', self.company_id.id), ('department_id', '=', self.department_id.id)])
        job_list = []
        for job in job_data:
            job_list.append(job.id)
        res = {'domain': {'designation': [('id', 'in', job_list)]}}
        print("job_list ", job_list)
        return res

    @api.onchange('designation')
    def onchange_in_designation(self):
        print("Inside designation")
        if self.designation:
            print(self.pr_company_id.company_id.id)
            print(self.pr_company_id.department_id.id)
            print(self.designation.id)
            approve_user_data = self.env['res.users.line'].sudo().search(
                [('company_id', '=', self.company_id.id),
                 ('department_id', '=', self.department_id.id),
                 ('designation', '=', self.designation.id)], limit=1)
            if approve_user_data:
                self.user_id = approve_user_data.res_user_id.id

    @api.onchange('approve_order')
    def onchange_in_approve_order(self):
        flag = 0
        try:
            approve_user_data = self.env['pr.approve.users'].sudo().search(
                [('pr_company_id', '=', int(str(self.pr_company_id.id).split('_')[1]))])
            flag = 1
        except Exception as e:
            pass
        if flag:
            for each_user in approve_user_data:
                # print("---", each_user.approve_order)
                if each_user.approve_order == self.approve_order:
                    raise ValidationError("Duplicate order!")


# class ProductRequestBudget(models.Model):
#     _name = "product.request.budget"
#     _description = "Product Request"
#
#     # company_id = fields.Many2one('res.company', string="Company Id")
#     # location = fields.Many2one('res.company', string="Location")
#     # department_id = fields.Many2one('hr.department', string="Department")
#     from_date = fields.Date("From Date", required=True)
#     to_date = fields.Date(string="To Date", required=True)
#     amount_allowed = fields.Float(string="Amount Allowed")
#     amount_used = fields.Float(string="Amount Used")
#     amount_available = fields.Float(string="Amount Available")
#     product_budget_id = fields.Many2one('pr.company', string='Pr Company Id',
#                                     invisible=True)