from datetime import datetime
from odoo import api, fields, models, _
# import datetime
import base64
import logging
import xlrd
from odoo.exceptions import ValidationError, MissingError, UserError

_logger = logging.getLogger(__name__)


class ProductRequest(models.Model):
    _name = "product.request"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Product Request"

    name = fields.Char(string="Request No", readonly=True, required=True, copy=False, default='New')
    requested_date = fields.Datetime(string="Requested Date", default=datetime.today(), readonly=True)

    product_request_line_ids = fields.One2many('product.request.line',
                                               'product_request_id',
                                               string='Product Request Line',
                                               tracking=True)

    pr_approve_line = fields.One2many('pr.approve.line',
                                      'product_request_id',
                                      string='Pr Approve Line',
                                      tracking=True)

    status = fields.Selection(
        selection=[('draft', 'DRAFT'), ('requested', 'REQUESTED'), ('accepted', 'APPROVED'), ('declined', 'REJECTED')],
        string='Requirement Status',
        default='draft',
        required=True
    )

    requested_by = fields.Many2one('res.users', 'Requested By', default=lambda self: self.env.user, readonly=True)

    approve_users = fields.Many2many(
        'res.users',
        'product_request_approve_users_rel',
        'request_id',
        'user_id',
        string='Approve Users',
        # default=lambda
        #     self: self.env.ref("product_purchase.group_initial_approval").users.ids
    )

    approved_users = fields.Many2many(
        'res.users',
        'product_request_approved_users_rel',
        'request_id',
        'user_id',
        string='Approved Users',
    )

    approve_check = fields.Boolean(compute="_approve_check", string="Approve Check", default=False)

    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)

    next_approve_user_id = fields.Many2one('res.users', string="Next Approve User ID")

    # current_user_id = fields.Many2one('res.users', string="Current User ID", default=lambda self: self.env.user.id)

    user_approve_check = fields.Boolean(string="User Approve check", compute="_compute_total", default=False)

    # product_request_budget_ids = fields.One2many('product.request.budget',
    #                                              'product_buget_id',
    #                                              string='Product Budget Line',
    #                                              tracking=True)
    bill_to = fields.Many2one('res.partner', "Bill To", required=True)

    ship_to = fields.Many2one('res.partner', "Ship To", required=True)

    expense_type = fields.Selection([('cap', 'CapEx'), ('op', 'OpEx')], string='Expense Type', tracking=True)

    location = fields.Many2one('res.company', string="Location")

    total_price = fields.Float(string="Total Price", compute="compute_total")
    deligated_user = fields.Many2one(
        'res.users', string='User Deligated', tracking=True, compute="_compute_user_id")

    # department_id = fields.Many2one('hr.department', string="Department")

    # @api.onchange('department_id')
    # def onchange_in_department_id(self):
    #     product_data = self.env['product.request.line'].search(
    #         [('product_request_id', '=', self.product_request_id.id)])
    #     product_list = []
    #     for product_line in product_data:
    #         product_list.append(product_line.product.id)
    #     print(product_list)
    #     res = {'domain': {'product': [('id', 'in', product_list)]}}
    #     return res

    def _compute_user_id(self):
        for rec in self:
            rec.deligated_user = self.env.user.id

    @api.onchange('total_price')
    def onchange_in_total_price(self):
        # self.total_price = self.total_price
        print("Inside total_price price", self.total_price)

    @api.depends('product_request_line_ids')
    def compute_total(self):
        total_amount = 0
        for total in self:
            for lines in total.product_request_line_ids:
                total_amount += lines.quantity * lines.unit_price
        print("total_amount ", total_amount)
        self.total_price = total_amount

    @api.depends("user_approve_check")
    def _compute_total(self):
        print('Inside user_approve_check')
        for rec in self:
            if rec.next_approve_user_id.id == self.env.user.id:
                rec.user_approve_check = True
            else:
                rec.user_approve_check = False

    def _approve_check(self):
        self.approve_check = False
        if self.approved_users and (self.env.user.id in [user_ids.id for user_ids in self.approved_users]):
            self.approve_check = True
        else:
            self.approve_check = False

    def action_request(self):
        pr_approve_line_data = self.env['pr.approve.line'].sudo().search(
            [('product_request_id', '=', self.id)])
        if not pr_approve_line_data:
            raise ValidationError("Approve list is empty")

        employee_data = self.env['hr.employee'].sudo().search([('user_id', '=', self.env.user.id)], limit=1)
        if not employee_data.department_id:
            raise ValidationError("Employee data is empty")

        pr_company_data = self.env['pr.company'].sudo().search([('company_id', '=', employee_data.company_id.id),
                                                                ('location', '=', employee_data.company_id.id),
                                                                ('department_id', '=', employee_data.department_id.id)],
                                                               limit=1)
        print("pr_company_data : ", pr_company_data)
        if not pr_company_data:
            raise ValidationError("Approval list is empty")
        else:
            pr_budget_data = self.env['product.request.budget'].sudo().search(
                [('company_id', '=', employee_data.company_id.id),
                 ('location', '=', employee_data.company_id.id),
                 ('department_id', '=', employee_data.department_id.id),
                 ('expense_type', '=', pr_company_data.expense_type),
                 ('amount_available', '>=', self.total_price)],
                limit=1)
            if not pr_budget_data:
                raise ValidationError(
                    "Limitations on the approved budget have been identified. Kindly reach out to the administrator "
                    "for further assistance.")
            else:
                pass
                # print("pr_budget_data.company_id ", pr_budget_data.company_id)
                # print("pr_budget_data.location ", pr_budget_data.location)
                # print("pr_budget_data.expense_type ", pr_budget_data.expense_type)
                # print("pr_budget_data.department_id ", pr_budget_data.department_id)
                # print("pr_budget_data.amount_available ", pr_budget_data.amount_available)
        if self.product_request_line_ids:
            self.status = 'requested'
            # print(self.approve_users)
            for item in self.product_request_line_ids:
                item.status = self.status
            # if vals.get('name', 'New') == 'New':
            #     vals['name'] = self.env['ir.sequence'].next_by_code('product.request') or 'New'
            #
            # result = super(ProductRequest, self).create(vals)

        else:
            raise ValidationError("Products are empty!")

    def purchase_request(self, data):
        print("Inside purchase request")

        for row in data:
            # print("---------------", row["master"]["partner_id"])
            invoice_date = row["master"]["date_approve"]
            # date = datetime.strptime(invoice_date, '%d/%m/%Y')

            vendor_gst = row["master"]["partner_id"]["gst_no"]
            if vendor_gst:
                vendor = vendor_gst and self.env['res.partner'].sudo().search(
                    [('vat', '=', vendor_gst)],
                    limit=1) or False
            else:
                raise ValueError("GST number is missing")

            order_line = []
            for product_line in row["child"]:
                product_item = product_line["name"]
                if product_item:
                    product = product_item and self.env['product.product'].sudo().search(
                        [('name', '=', product_item)], limit=1) or False
                    uom_ids = self.env['uom.uom'].sudo().search([])
                    unit_id = self.env.ref('uom.product_uom_unit') and self.env.ref(
                        'uom.product_uom_unit').id or False
                    for record in uom_ids:
                        if record.name == "kg":
                            unit_id = record.id
                    if not product:
                        product_details = {
                            'name': product_line["name"],
                            # 'default_code': row.ITEM_NUM,
                            'list_price': product_line["price_unit"],
                            # 'l10n_in_hsn_code': row.HSN_CODE,
                            'uom_id': unit_id,
                            'uom_po_id': unit_id,
                            'detailed_type': 'product',
                            'categ_id': 1,
                            'standard_price': product_line["price_unit"],

                        }

                        product = self.env['product.template'].sudo().create(product_details)
                        self.env.cr.commit()
                        # print("product template")
                if product:
                    order_line.append((0, 0, {
                        'display_type': False,
                        # 'sequence': 10,
                        'product_id': product.id,
                        'name': product.name or '',
                        # 'date_planned': row.TRANSACTION_DATE or False,
                        'account_analytic_id': False,
                        'product_qty': product_line["product_qty"] or 0,
                        'qty_received_manual': 0,
                        # 'discount': discount or 0,
                        # 'product_uom': product.uom_id.id or request.env.ref(
                        #     'uom.product_uom_unit') and request.env.ref('uom.product_uom_unit').id or False,
                        'price_unit': product_line["price_unit"] or 0,
                        # 'taxes_id': tax_variant and [(6, 0, [tax_variant.id])] or [],
                    }))
        if vendor:
            purchase_order_1 = self.env['purchase.order'].create({
                'partner_id': vendor.id,
                # 'partner_ref': row.SALES_ORDER_NUMBER or '',
                # 'origin': row.INVOICE_NUM or '',
                # 'date_order':row["master"]["date_order"] or False,
                # 'date_planned':row["master"]["date_approve"] or False,
                # 'partner_id': self.env.ref('base.main_partner').id,
                # 'name': row.INVOICE_NUM or '',
                'bill_to': self.bill_to.id,
                'ship_to': self.ship_to.id,
                'order_line': order_line,
            })
            self.env.cr.commit()

    def action_deligate(self):
        print("deligate")
        for lines in self.pr_approve_line:
            if lines.user_id.id == self.env.user.id:
                print("Founddd User")
                action = self.env["ir.actions.actions"]._for_xml_id('product_purchase.update_deligate_user_action')
                action['context'] = {'default_request_id': self.id}

                return action

    def action_approval(self):
        self.write({'approved_users': [(4, self.env.user.id)]})
        print(self.approve_users)
        print(self.approved_users)
        approve_users = self.env['pr.approve.line'].sudo().search(
            [('product_request_id', '=', self.id), ('user_id', '=', self.env.user.id)], )

        approve_users.write({
            'status': 'accept'
        })

        if self.approved_users == self.approve_users:
            self.status = 'accepted'
            # Vendor Purchase Order Creation when a contract exists.
            for line_item in self.product_request_line_ids:
                # print(line_item.product.name)
                product_tender_line_data = self.env['product.tender.line'].sudo().search(
                    [('product_template_id', '=', line_item.product.id)])
                # print(product_tender_line_data)
                if product_tender_line_data:
                    partner_id = {}
                    data = []
                    for tender_data in product_tender_line_data:
                        data = []
                        address = ''
                        child = []
                        # print(tender_data)
                        print("tender_data.vendor.name : ", tender_data.vendor.name)
                        # print(tender_data.product_template_id)
                        if tender_data.vendor.street:
                            address = address + str(tender_data.vendor.street) + " "
                        if tender_data.vendor.street2:
                            address = address + str(tender_data.vendor.street2) + " "
                        if tender_data.vendor.city:
                            address = address + str(tender_data.vendor.city) + " "
                        if tender_data.vendor.state_id.name:
                            address = address + str(tender_data.vendor.state_id.name) + " "
                        if tender_data.vendor.zip:
                            address = address + str(tender_data.vendor.zip) + " "
                        if tender_data.vendor.country_id.name:
                            address = address + str(tender_data.vendor.country_id.name)
                        partner_id = {
                            "name": tender_data.vendor.name,
                            "ref": "",
                            "address": address,
                            "phone": tender_data.vendor.phone,
                            "email": tender_data.vendor.email,
                            "gst_no": tender_data.vendor.vat,
                            "state": str(tender_data.vendor.state_id.name),
                        }
                        child.append({
                            "name": tender_data.product_template_id.name,
                            "product_qty": line_item.quantity,
                            "discount": 0,
                            "rate": tender_data.unit_price,
                            "cgst": 0,
                            "sgst": 0,
                            "igst": 0,
                            "price_unit": tender_data.unit_price
                        })
                        master = {
                            "orderID": None,
                            "date_approve": datetime.now(),
                            "partner_id": partner_id
                        }
                        data_dict = {
                            "master": master,
                            "child": child
                        }
                        data.append(data_dict)
                        print("data : ", data)
                        self.purchase_request(data)
                else:
                    if line_item.vendors:
                        vendor_id_list = [item.id for item in self.product_request_line_ids.vendors]
                        for vendor_id in vendor_id_list:
                            vendor = self.env['res.partner'].sudo().search(
                                [('id', '=', vendor_id)])
                            requested_company = self.env['res.users'].sudo().search(
                                [('id', '=', self.env.user.id)])
                            if not requested_company:
                                raise ValidationError(_("No company found for the current user"))
                            if not vendor.user_id.id:
                                raise ValidationError(_("Company user is missing"))
                            print(requested_company.company_id.name)
                            # Creating contract request
                            vals = {
                                'product': line_item.product.id,
                                'requested_to': vendor_id,
                                'requested_by': requested_company.company_id.id,
                                'quantity': line_item.quantity,
                                'unit_price': line_item.unit_price,
                                'total_price': line_item.quantity * line_item.unit_price,
                                'requested_date': self.requested_date,
                                'expected_date': line_item.expected_date,
                                # 'customer': vendor_id,
                                'user_id': vendor.user_id.id,
                                'request_check': True,
                                'vendor_request_check': False,
                                'product_requested_id': self.id,
                                'product_request_line_id': line_item.id
                            }
                            print("vals : ", vals)
                            tender_record = self.env['tender.request'].create(vals)

                            # Adding a new contract to the list of all contracts
                            tender_record = self.env['tenders'].create({
                                'product': line_item.product.id,
                                'requested_to': vendor_id,
                                'requested_by': requested_company.company_id.id,
                                'quantity': line_item.quantity,
                                'unit_price': line_item.unit_price,
                                'total_price': line_item.quantity * line_item.unit_price,
                                'requested_date': self.requested_date,
                                'expected_date': line_item.expected_date,
                                'product_requested_id': self.id,
                                # 'tender_deadline': self.tender_deadline
                            })
        else:
            print("self.id : ", self.id)
            approve_users = self.env['pr.approve.line'].sudo().search([('product_request_id', '=', self.id)],
                                                                      order='approve_order asc')

            user_ids = [{'u_id': user.user_id.id, 'order': user.approve_order} for user in approve_users]
            print(user_ids)
            for user in user_ids:
                if self.env.user.id == user['u_id']:
                    self.next_approve_user_id = user_ids[user_ids.index(user) + 1]['u_id']

    def action_decline(self):
        self.status = 'declined'

    def total_price_calculation(self, result):
        total_price = 0
        print(self.product_request_line_ids)
        print(result.product_request_line_ids)
        if self.product_request_line_ids:
            total_price = 0
            for line_product in self.product_request_line_ids:
                print(line_product.unit_price)
                print(line_product.quantity)
                total_price += line_product.unit_price * line_product.quantity
        elif result.product_request_line_ids:
            total_price = 0
            for line_product in result.product_request_line_ids:
                print(line_product.unit_price)
                print(line_product.quantity)
                total_price += line_product.unit_price * line_product.quantity
        else:
            raise ValidationError("Product list is empty!")
        print("return ", total_price)
        return total_price

    @api.model
    def create(self, vals):
        # Calculating total price
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('product.request') or 'New'

        result = super(ProductRequest, self).create(vals)
        total_price_sum = self.total_price_calculation(result)
        print(total_price_sum)
        print(result.total_price)
        if total_price_sum <= 0:
            raise ValidationError("Invalid price!")
        # print("self.company_id.id ", self.env.company.id)
        employee_data = self.env['hr.employee'].sudo().search([('user_id', '=', self.env.user.id)], limit=1)
        if not employee_data.department_id:
            raise ValidationError("Employee data is empty")
        pr = self.env['product.request'].sudo().search([('id', '=', result.id)], limit=1)
        pr.write({'total_price': total_price_sum})
        print('employee_data.company_id.id ', employee_data.company_id.id)
        print("employee_data.company_id.id ", employee_data.company_id.id)
        print("employee_data.department_id.id ", employee_data.department_id.id)
        print("self.total_price ", pr.total_price)

        pr_company_data = self.env['pr.company'].sudo().search([('company_id', '=', employee_data.company_id.id),
                                                                ('location', '=', employee_data.company_id.id),
                                                                ('department_id', '=', employee_data.department_id.id),
                                                                ('from_amount', '<=', pr.total_price),
                                                                ('to_amount', '>=', pr.total_price)],
                                                               limit=1)
        print("pr_company_data ", pr_company_data)
        if pr_company_data:
            approve_user_ids = []
            pr_company_line_data = self.env['pr.approve.users'].sudo().search(
                [('pr_company_id', '=', pr_company_data.id)])
            # print("pr_company_line_data ", pr_company_line_data)
            for pr_user in pr_company_line_data:
                # print(pr_user.user_id.id)
                pr.write({'approve_users': [(4, pr_user.user_id.id)]})
                vals = {
                    'user_id': pr_user.user_id.id,
                    'company_id': pr_user.company_id.id,
                    'location': pr_user.location.id,
                    'department_id': pr_company_data.department_id.id,
                    'designation': pr_user.designation.id,
                    'approve_order': pr_user.approve_order,
                    'product_request_id': pr.id
                }
                approve_user_ids.append({'user_id': pr_user.user_id.id,
                                         'approve_order': pr_user.approve_order})
                # print("vals ", vals)
                pr_approve_line = self.env['pr.approve.line'].create(vals)
                self.env.cr.commit()
            if approve_user_ids:
                # print("before sorting : ", approve_user_ids)
                mylist = sorted(approve_user_ids, key=lambda k: (k['approve_order']))
                pr.write({'next_approve_user_id': mylist[0]['user_id']})
        else:
            raise ValidationError("Approve Users are empty")
        return result


class ProductRequestLine(models.Model):
    _name = "product.request.line"
    _description = "Product Request"

    product = fields.Many2one('product.template', string="Product", store=True, force_save=True, required=True)
    quantity = fields.Float(string="Quantity", required=True)
    expected_date = fields.Date(string="Expecting Date", required=True)
    requirement_status = fields.Selection(
        selection=[('draft', 'Within 30 days'), ('open', 'Within 15 days'), ('immediate', 'Within 5 days')],
        string='Requirement Status',
        default='draft',
        required=True
    )
    unit_price = fields.Float(string="Unit Price", required=True)
    description = fields.Char(string="Description")
    company_id = fields.Many2one(
        "res.company",
        string="Company",
        default=lambda self: self.env.company,
        invisible=True
    )

    vendors = fields.Many2many('res.partner', string="Vendors", required=True)

    status = fields.Selection(
        selection=[('draft', 'Draft'), ('requested', 'Requested'), ('accepted', 'Accepted'), ('reject', 'Rejected')],
        string='Status',
        default='draft',
        required=True
    )

    contract_status = fields.Selection(
        selection=[('new', 'New'), ('in_contract', 'In Contract')],
        string='Contract Status',
        default='new',
        required=True
    )

    product_request_id = fields.Many2one('product.request', string='Product Request Id',
                                         invisible=True)
    tender_deadline = fields.Date(string="Contract Deadline")

    @api.onchange('product')
    def onchange_in_product(self):
        print(" self.product.id ", self.product)
        product_tender_line_data = self.env['product.tender.line'].sudo().search(
            [('product_template_id', '=', self.product.id), ('company_id', '=', self.company_id.id)])
        vendor_list = []
        print("product_tender_line_data : ", product_tender_line_data)
        if product_tender_line_data:
            for tender_data in product_tender_line_data:
                vendor_list.append(tender_data.vendor.id)
            self.vendors = vendor_list
            self.contract_status = 'in_contract'

    def change_valuation(self):
        print('change_valuation', self.product_request_id.id)
        try:
            pr_approve_user = self.env['pr.approve.line'].sudo().search(
                [('product_request_id', '=', int(str(self.product_request_id.id).split('_')[1]))], )
            for item in pr_approve_user:
                print("unlink")
                item.unlink()
        except:
            print("Pass")
            pass

    @api.onchange('unit_price')
    def onchange_in_unit_price(self):
        self.unit_price = self.unit_price
        print("Inside unit price")
        # print(self.id)
        # try:
        #     # for line in self:
        #     #     print("inside")
        #     #     print(line.unit_price)
        #     product_request_line_data = self.env['product.request.line'].sudo().search(
        #         [('product_request_id', '=', int(str(self.product_request_id.id).split('_')[1]))])
        #     # self.change_valuation()
        #     total_price = 0
        #     for product_line in product_request_line_data:
        #         print(product_line.id)
        #         if product_line.id == int(str(self.id).split('_')[1]):
        #             total_price += product_line.quantity * self.unit_price
        #         else:
        #             total_price += product_line.quantity * product_line.unit_price
        #         print(product_line.product.name)
        #         print(product_line.unit_price)
        #     print("Total price : ", total_price)
        #     pr_data = self.env['product.request'].sudo().search(
        #         [('id', '=', int(str(self.product_request_id.id).split('_')[1]))], limit=1)
        #     if pr_data:
        #         pr_data.write({'total_price': total_price})
        #     else:
        #         raise val
        # except:
        #     print(self.id)
        #     pass

    @api.onchange('quantity')
    def onchange_in_quantity(self):
        self.quantity = self.quantity

    # @api.constrains('quantity')
    # def _quantity_check(self):
    #     if not self.quantity > 0:
    #         raise ValidationError(_('Invalid quantity'))
    #
    # @api.constrains('unit_price')
    # def _unit_price_check(self):
    #     if not self.quantity > 0:
    #         raise ValidationError(_('Invalid quantity'))


class PrApproveLine(models.Model):
    _name = "pr.approve.line"
    _description = "Approve Line"

    product_request_id = fields.Many2one('product.request', string='Product Request Id',
                                         invisible=True)

    user_id = fields.Many2one('res.users', string="User")
    company_id = fields.Many2one('res.company', string="Company Id")
    location = fields.Many2one('res.company', string="Location")
    department_id = fields.Many2one('hr.department', string="Department")
    emp_name = fields.Many2one('hr.employee', string="Employee")
    designation = fields.Many2one('hr.job', string="Designation")
    approve_order = fields.Integer(string="Order")
    status = fields.Selection(
        selection=[('draft', 'Draft'), ('accept', 'Accept'), ('cancel', 'Cancel'), ('deligate', 'Deligated')],
        string='Status',
        default='draft',
        required=True, tracking=True
    )

    # @api.model
    # def create(self, vals):
    #
    #             # print(item.user_id.name)
    #             # print(item.approve_order)
    #             result = super(PrApproveLine, self).create(vals)
