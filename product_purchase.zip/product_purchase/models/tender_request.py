from datetime import datetime
from odoo import api, fields, models, _
# import datetime
import base64
import logging
import xlrd
from odoo.exceptions import ValidationError, MissingError, UserError

_logger = logging.getLogger(__name__)


class TenderRequest(models.Model):
    _name = "tender.request"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Tender Request"

    name = fields.Char(string="TRN", readonly=True, required=True, copy=False, default='New')
    product = fields.Many2one('product.template', string="Product", store=True, force_save=True)
    requested_to = fields.Many2one('res.partner', string="Vendor", store=True, force_save=True)
    requested_by = fields.Many2one('res.partner', string="Requested By", store=True, force_save=True)
    quantity = fields.Float(string="Quantity", tracking=True)
    unit_price = fields.Float(string="Unit Price", tracking=True)
    total_price = fields.Float(string="Total Price")
    requested_date = fields.Date(string="Requested Date", tracking=True)
    expected_date = fields.Date(string="Expected Date", tracking=True)
    tender_deadline = fields.Date(string="Contract Deadline")
    user_id = fields.Many2one('res.users', string="Requested To")
    tender_status = fields.Selection([('draft', 'Draft'),
                                      ('accept', 'Accept'),
                                      ('cancel', 'Cancel')], string='Contract Status',
                                     default='draft', tracking=True)
    vendor_request_status = fields.Selection([('draft', 'Draft'),
                                              ('requested', 'Requested'),
                                              ('accept', 'Accept'),
                                              ('cancel', 'Cancel')], string='Tender Status of Vendor',
                                             default='draft')
    vendor_request_check = fields.Boolean(string="Vendor Request Check", default=True)
    request_check = fields.Boolean(string="Request Check", default=False)
    process_complete_check = fields.Boolean(string="Process Check", default=False)
    product_requested_id = fields.Float(string="Product Requested ID")
    product_request_line_id = fields.Many2one('product.request.line', string="Product Requested ID")
    # company_id = fields.Float(string="Company ID")

    @api.onchange('quantity')
    def onchange_in_quantity(self):
        print("Inside quantity on change")
        if self.quantity:
            self.total_price = self.quantity * self.unit_price

    @api.onchange('unit_price')
    def onchange_in_unit_price(self):
        print(self.request_check)
        print("Inside unit_price on change")
        if self.unit_price:
            self.total_price = self.quantity * self.unit_price

    def action_tender_request_draft(self):
        self.tender_status = 'draft'
        self.process_complete_check = False

    def action_tender_request_accept(self):
        print(self.request_check)
        self.process_complete_check = True
        print("action_tender_request_accept")
        self.tender_status = 'accept'
        print(self.tender_status)
        tender_request_response = self.env['tender.request.response'].create({
            'product': self.product.id,
            'response_from': self.requested_to.id,
            'quantity': self.quantity,
            'unit_price': self.unit_price,
            'total_price': self.total_price,
            'requested_date': self.requested_date,
            'expected_date': self.expected_date,
            'product_requested_id': self.product_requested_id,
            'product_request_line_id': self.product_request_line_id.id,
            'status': 'accept',
            'company_id': self.requested_by.id,
            'user_id': self.user_id.id,
            'bid_check': False
        })

    def action_tender_request_cancel(self):
        print("action_tender_request_accept")
        self.process_complete_check = True
        self.tender_status = 'cancel'
        tender_request_response = self.env['tender.request.response'].create({
            'product': self.product.id,
            'response_from': self.requested_to.id,
            'quantity': self.quantity,
            'unit_price': self.unit_price,
            'total_price': self.total_price,
            'requested_date': self.requested_date,
            'expected_date': self.expected_date,
            'product_requested_id': self.product_requested_id,
            'product_request_line_id': self.product_request_line_id.id,
            'status': 'cancel',
            'company_id': self.requested_by.id,
            # 'bid_check': True
        })

    def action_tender_request_send(self):
        self.vendor_request_status = 'requested'
        self.vendor_request_check = True

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('tender.request') or 'New'

        result = super(TenderRequest, self).create(vals)
        return result
