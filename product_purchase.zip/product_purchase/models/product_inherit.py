from odoo import api, fields, models, _


class ProductInherit(models.Model):
    _inherit = "product.template"

    product_tender_line_id = fields.One2many('product.tender.line',
                                             'product_template_id',
                                             string='Product Tender Line',
                                             tracking=True)


class ProductTenderLine(models.Model):
    _name = "product.tender.line"
    _description = "Product Tender Lines"

    tender_number = fields.Char(string="Tender No", readonly=True, required=True, copy=False, default='New')
    purchase_tender_type = fields.Char(string='Tender Type')
    vendor = fields.Many2one('res.partner', string='Vendor')
    purchase_representative = fields.Many2one('res.users', string='Purchase Representative')
    quantity = fields.Float(string='Quantity')
    unit_price = fields.Float(string='Unit Price')
    total = fields.Float(string='Total')
    company_id = fields.Many2one(
        "res.company",
        string="Company",
        default=lambda self: self.env.company,
        invisible=True
    )
    user_id = fields.Many2one('res.users', 'User', default=lambda self: self.env.user, invisible=True)
    product_template_id = fields.Many2one('product.template', string='Product Template Id',
                                          invisible=True)
    tender_deadline = fields.Date(string="Deadline")

    @api.model
    def create(self, vals):
        if vals.get('tender_number', 'New') == 'New':
            vals['tender_number'] = self.env['ir.sequence'].next_by_code('product.tender.line') or 'New'

        result = super(ProductTenderLine, self).create(vals)

        return result

    @api.onchange('quantity')
    def onchange_in_quantity(self):
        print("Inside quantity on change")
        if self.quantity:
            self.total = self.quantity * self.unit_price

    @api.onchange('unit_price')
    def onchange_in_unit_price(self):
        # print(self.request_check)
        print("Inside unit_price on change")
        if self.unit_price:
            self.total = self.quantity * self.unit_price




