from odoo import api, fields, models
from odoo.exceptions import ValidationError, MissingError, UserError


class BiddingVendor(models.Model):
    _name = "bidding.vendor"
    _description = "Vendor Bid"

    bid_id = fields.Many2one('bidding', string="Bidding ID")
    vendor = fields.Many2one('res.partner', string="vendor")
    product_id = fields.Many2one('product.template', string="Product")
    price = fields.Float(sting="Price")
    rank = fields.Integer(string="Rank", default=None)


