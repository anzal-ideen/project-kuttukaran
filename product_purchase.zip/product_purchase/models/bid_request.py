from odoo import api, fields, models
from odoo.exceptions import ValidationError, MissingError, UserError


class BidRequest(models.Model):
    _name = "bid.request"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Bidding Request"

    name = fields.Char(string="Bid Request No", readonly=True, required=True, copy=False, default='New')
    product_id = fields.Many2one('product.template', string="Product", store=True, force_save=True, required=True)
    quantity = fields.Float(string="Quantity")
    unit_price = fields.Float(string="Unit price")
    total_price = fields.Float(string="Total price")
    date = fields.Date(string="Requested Date")
    time = fields.Float(string='Time')
    deadline = fields.Date(string='DeadLine')
    status = fields.Selection(
        selection=[('draft', 'Draft'), ('accept', 'Accept'), ('reject', 'Reject')],
        string='Bidding Status',
        default='draft',
        required=True,
        tracking=True
    )
    bidding_date = fields.Date(string="Bidding Date")
    request_from = fields.Many2one('res.partner', string="Request from")
    request_to = fields.Many2one('res.partner', string="Request To")
    user_id = fields.Many2one('res.users', string="User Id")
    bidding_id = fields.Many2one('bidding', string="Bidding ID")
    product_requested_id = fields.Integer(string="Product Request ID")
    product_request_line_id = fields.Many2one('product.request.line', string="Product Requested ID")

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('bid.request') or 'New'
        result = super(BidRequest, self).create(vals)
        return result

    def action_accept_bid(self):
        print("action_accept_bid")
        print(self.bidding_id.id)
        bidding_data = self.env['bidding'].sudo().search(
            [('id', '=', self.bidding_id.id)])
        bidding_data.write({'vendors': [(4, self.request_to.id)]})

        print({
            'Bid_name': self.bidding_id.name,
            'bid_id': self.bidding_id.id,
            'bid_request_id': self.id,
            'request_from': self.request_from.id,
            'request_to': self.request_to.id,
            'product_id': self.product_id.id,
            'quantity': self.quantity,
            'unit_price': self.unit_price,
            'user_id': self.user_id.id
        })

        vendor_bid = self.env['vendor.bid'].create({
            'Bid_name': self.bidding_id.name,
            'bid_id': self.bidding_id.id,
            'bid_request_id': self.id,
            'request_from': self.request_from.id,
            'request_to': self.request_to.id,
            'product_id': self.product_id.id,
            'quantity': self.quantity,
            'unit_price': self.unit_price,
            'user_id': self.user_id.id
        })

        self.status = "accept"

    def action_reject_bid(self):
        print("action_reject_bid")
        self.status = "reject"

    def action_draft_bid(self):
        print("action_draft_bid")
        self.status = "draft"

    def action_open_bid(self):
        print(self.id)
        vendor_bid_data = self.env['vendor.bid'].sudo().search(
            [('bid_request_id', '=', self.id)])
        print(vendor_bid_data)
        return {
            'type': 'ir.actions.act_window',
            'name': 'Vendor Bid',
            'res_model': 'vendor.bid',
            'domain': [('id', 'in', vendor_bid_data.ids)],
            'view_mode': 'tree,form',
            'target': 'current'
        }