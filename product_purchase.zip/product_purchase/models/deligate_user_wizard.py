from datetime import datetime
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, MissingError, UserError


class DeligateUserWizard(models.TransientModel):
    _name = "deligate.user.wizard"
    _description = "Deligate User"

    deligate_user = fields.Many2one('res.users',string="User", store=True,required=True)
    # company_id = fields.Many2one('res.users',string="User", store=True,required=True)
    # department = fields.Many2one('res.users',string="User", store=True,required=True)

    request_id = fields.Many2one(
        'product.request', string='Product Request', readonly=True)



    def confirm(self):
        print("hellooo")
        print(self.deligate_user.id)
        print(self.request_id.name)

        # deligate_user = self.env['res.users'].browse(self.deligate_user.id)
        # for designation in deligate_user.res_user_line_id:
        #     print(designation.company_id)
        # for users in self.deligate_user:
        #     for details in users.res_user_line_id:
        #         print(details.company_id)


        for lines in self.request_id.pr_approve_line:
            if lines.user_id.id == self.env.user.id:
                if lines.status == 'draft':
                    for lines in self.request_id.pr_approve_line:
                        if lines.user_id.id == self.env.user.id:
                            lines.product_request_id.write({
                                'approved_users': [(4, lines.user_id.id)]
                            })
                            lines.product_request_id.write({
                                'approve_users': [(4, self.deligate_user.id)]
                            })
                            lines.product_request_id.next_approve_user_id = self.deligate_user.id
                            for rec in lines.product_request_id.approve_users:
                                print(rec.name)

                            new_line_vals = {
                                'user_id': self.deligate_user.id,
                                # 'company_id': 'value2',
                                # 'location': 'value2',
                                # 'department_id': 'value2',
                                # 'designation': 'value2',
                                'approve_order': lines.approve_order,
                            }
                            self.request_id.pr_approve_line |= self.env['pr.approve.line'].create(new_line_vals)
                            lines.approve_order = ''
                            lines.status ='deligate'
                            lines.product_request_id.deligated_user = self.deligate_user.id
                else:
                    raise UserError("User has already deligated once")
