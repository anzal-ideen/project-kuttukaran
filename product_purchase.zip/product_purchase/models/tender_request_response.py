from datetime import datetime
from odoo import api, fields, models, _
import base64
import logging
import xlrd
from odoo.exceptions import ValidationError, MissingError, UserError

_logger = logging.getLogger(__name__)


class TenderRequestResponse(models.Model):
    _name = "tender.request.response"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Tender Request Response"

    name = fields.Char(string="TRN", readonly=True, required=True, copy=False, default='New')
    product = fields.Many2one('product.template', string="Product", store=True, force_save=True)
    quantity = fields.Float(string="Quantity")
    unit_price = fields.Float(string="Unit Price")
    total_price = fields.Float(string="Total Price")
    status = fields.Selection([
        ('accept', 'Accept'),
        ('cancel', 'Cancel')], string='Contract Status', tracking=True)
    requested_date = fields.Date(string="Requested Date")
    expected_date = fields.Date(string="Expected Date")
    response_from = fields.Many2one('res.partner', string="Vendor", store=True, force_save=True)
    product_requested_id = fields.Integer(string="Product Request Id")
    product_request_line_id = fields.Many2one('product.request.line', string="Product Requested ID")
    tender_response_qtn_check = fields.Boolean(string="Tender qtn Comp Check", default=False)
    tender_response_tender_check = fields.Boolean(string="Tender Res Comp Check", default=False)
    request_quotation = fields.Char(string="RFQ")
    purchase_request = fields.Char(string="Purchase Request")
    company_id = fields.Many2one('res.partner', string="Company")
    contract_check = fields.Boolean(string="Contract Check", compute="_contract_check", default=False)
    tender_deadline = fields.Date(string="Contract Deadline")

    time = fields.Float(string='Time')
    deadline = fields.Date(string='DeadLine')
    bidding_date = fields.Date(string="Bidding Date")
    request_from = fields.Many2one('res.partner', string="Request from")
    request_to = fields.Many2one('res.partner', string="Request To")
    user_id = fields.Many2one('res.users', string="User")
    bidding_id = fields.Many2one('bidding', string="Bidding ID")
    bid_check = fields.Boolean(string="Bid check", default="False")

    def _contract_check(self):
        print("_contract_check")
        product_tender_line_data = self.env['product.tender.line'].sudo().search(
            [('product_template_id', '=', self.product.id), ('vendor', '=', self.response_from.id)], limit=1)
        if product_tender_line_data:
            print("product_tender_line_data : ", product_tender_line_data.vendor.name)
            print("product_tender_line_data : ", product_tender_line_data.tender_number)
            self.contract_check = True
        else:
            self.contract_check = False

    def action_open_poq(self):
        print("Test")
        print(self.id)
        product_tender_line_data = self.env['purchase.order'].sudo().search(
            [('tender_rfq_id', '=', self.id)])
        print(product_tender_line_data)
        return {
            'type': 'ir.actions.act_window',
            'name': 'RFQ',
            'res_model': 'purchase.order',
            'domain': [('id', 'in', product_tender_line_data.ids)],
            'view_mode': 'tree,form',
            'target': 'current'
        }

    def action_open_purchase_request(self):
        print("Test")
        print(self.id)
        product_tender_line_data = self.env['product.request'].sudo().search(
            [('id', '=', self.product_requested_id)])
        print(product_tender_line_data)
        if self.product_requested_id:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Purchase Request',
                'res_model': 'product.request',
                'domain': [('id', '=', self.product_requested_id)],
                'view_mode': 'tree,form',
                'target': 'current'
            }
        else:
            raise ValidationError(_('Purchase Request Id is empty'))

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('tender.request.response') or 'New'

        result = super(TenderRequestResponse, self).create(vals)
        return result

    def action_create_tender(self):
        print('company_id', self.company_id.id)
        print('request_from', self.request_from.id)

        tender_record = self.env['product.tender.line'].sudo().create({
            'vendor': self.response_from.id,
            # 'purchase_representative': user_id,
            'tender_deadline': self.tender_deadline,
            'product_template_id': self.product.id,
            'company_id': self.product.company_id.id,
            'quantity': self.quantity,
            'unit_price': self.unit_price,
            'total': self.total_price
        })
        self.tender_response_tender_check = True

    def action_create_quotation(self):
        vendor = self.env['product.tender.line'].sudo().search(
            [('product_template_id', '=', self.product.id), ('vendor', '=', self.response_from.id),
             ('company_id', '=', self.product.company_id.id)],
            limit=1) or False
        print(vendor)
        if not vendor:
            raise ValidationError(_('Contract is empty'))
        print("action_create_quotation ", self.id)
        data = []
        child = []
        address = ''
        if self.response_from.street:
            address = address + str(self.response_from.street) + " "
        if self.response_from.street2:
            address = address + str(self.response_from.street2) + " "
        if self.response_from.city:
            address = address + str(self.response_from.city) + " "
        if self.response_from.state_id.name:
            address = address + str(self.response_from.state_id.name) + " "
        if self.response_from.zip:
            address = address + str(self.response_from.zip) + " "
        if self.response_from.country_id.name:
            address = address + str(self.response_from.country_id.name)

        partner_id = {
            "name": self.response_from.name,
            "ref": "",
            "address": address,
            "phone": self.response_from.phone,
            "email": self.response_from.email,
            "gst_no": self.response_from.vat,
            "state": str(self.response_from.state_id.name)
        }
        child.append({
            "name": self.product.name,
            "product_qty": self.quantity,
            "discount": 0,
            "rate": self.unit_price,
            "cgst": 0,
            "sgst": 0,
            "igst": 0,
            "price_unit": self.unit_price
        })
        master = {
            "orderID": None,
            "date_approve": datetime.now(),
            "partner_id": partner_id
        }

        data_dict = {
            "master": master,
            "child": child
        }
        data.append(data_dict)
        print("data : ", data)

        for row in data:
            # print("---------------")
            invoice_date = row["master"]["date_approve"]
            # date = datetime.strptime(invoice_date, '%d/%m/%Y')
            vendor_gst = row["master"]["partner_id"]["gst_no"]
            if vendor_gst:
                vendor = vendor_gst and self.env['res.partner'].sudo().search(
                    [('id', '=', self.response_from.id)],
                    limit=1) or False
                if not vendor:
                    raise ValueError("Vendor is missing")
            else:
                raise ValueError("GST number is missing")

            order_line = []
            for product_line in row["child"]:
                product_item = product_line["name"]
                if product_item:
                    product = product_item and self.env['product.product'].sudo().search(
                        [('name', '=', product_item)], limit=1) or False
                    uom_ids = self.env['uom.uom'].sudo().search([])
                    unit_id = self.env.ref('uom.product_uom_unit') and self.env.ref(
                        'uom.product_uom_unit').id or False
                    for record in uom_ids:
                        if record.name == "kg":
                            unit_id = record.id
                    if not product:
                        raise ValueError("Product is missing")
                if product:
                    order_line.append((0, 0, {
                        'display_type': False,
                        # 'sequence': 10,
                        'product_id': product.id,
                        'name': product.name or '',
                        # 'date_planned': row.TRANSACTION_DATE or False,
                        'account_analytic_id': False,
                        'product_qty': product_line["product_qty"] or 0,
                        'qty_received_manual': 0,
                        # 'discount': discount or 0,
                        # 'product_uom': product.uom_id.id or request.env.ref(
                        #     'uom.product_uom_unit') and request.env.ref('uom.product_uom_unit').id or False,
                        'price_unit': product_line["price_unit"] or 0,
                        # 'taxes_id': tax_variant and [(6, 0, [tax_variant.id])] or [],
                    }))
        if vendor:
            pr = self.env['product.request'].search([('id','=', self.product_requested_id)], limit=1)
            if not pr:
                raise ValidationError("PR not found!")
            purchase_order_1 = self.env['purchase.order'].create({
                'partner_id': vendor.id,
                # 'partner_ref': row.SALES_ORDER_NUMBER or '',
                # 'origin': row.INVOICE_NUM or '',
                # 'date_order':row["master"]["date_order"] or False,
                # 'date_planned':row["master"]["date_approve"] or False,
                # 'partner_id': self.env.ref('base.main_partner').id,
                # 'name': row.INVOICE_NUM or '',
                'order_line': order_line,
                'tender_rfq_id': self.id,
                'bill_to': pr.bill_to.id,
                'ship_to': pr.ship_to.id,
            })
            # purchase_order_1.button_confirm()
            self.tender_response_qtn_check = True
            self.env.cr.commit()

    def action_cancel(self):
        self.status = 'cancel'

    def action_add_to_bidding(self):
        dict_data = {
            'product_id': self.product.id,
            'quantity': self.quantity,
            'unit_price': self.unit_price,
            'total_price': self.total_price,
            'requested_date': datetime.now(),
            'time': self.time,
            'deadline': self.bidding_id.date,
            'status': self.status,
            'bidding_date': self.bidding_id.date,
            'request_from': self.company_id.id,
            'request_to': self.response_from.id,
            'user_id': self.user_id.id,
            'bidding_id': self.bidding_id.id,
            'response_id': self.id,
            'product_requested_id': self.product_requested_id,
            'product_request_line_id': self.product_request_line_id.id
        }
        # self.bid_check = True
        return {
            'type': 'ir.actions.act_window',
            'name': 'Add to Bidding wizard',
            'view_mode': 'form',
            'target': 'new',
            'res_model': 'add.to.bidding.wizard',
            'context': {
                'product_id': self.product.id,
                'quantity': self.quantity,
                'unit_price': self.unit_price,
                'total_price': self.total_price,
                'requested_date': datetime.now(),
                'time': self.time,
                'deadline': self.bidding_id.date,
                'status': self.status,
                'bidding_date': self.bidding_id.date,
                'request_from': self.company_id.id,
                'request_to': self.response_from.id,
                'user_id': self.user_id.id,
                'bidding_id': self.bidding_id.id,
                'response_id': self.id,
                'product_requested_id': self.product_requested_id,
                'product_request_line_id': self.product_request_line_id
            }
        }

    def action_report_download(self):
        print("Inside action_report_download")
        return self.env.ref('product_purchase.report_vendor_contract').report_action(self)
